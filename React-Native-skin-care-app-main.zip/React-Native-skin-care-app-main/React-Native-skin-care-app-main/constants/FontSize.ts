const xs: number = 12;
const sm: number = 14;
const base: number = 16;
const lg: number = 20;
const xl: number = 30;
const xxl: number = 35;

export default {
  xs,
  sm,
  base,
  lg,
  xl,
  xxl,
};
