declare module "react-native-easy-rating";
